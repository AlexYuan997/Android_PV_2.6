﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cabinet4Producer.Client
{
    public class Etv002DataProtocol
    {
        public const byte BEGIN_FLAG = (byte)0xB0;

        //设备自身通道
        public const byte CHAN_DEVICESELF = (byte)0x00;
        //IO 模块通道,Mensuo通道
        public const byte CHAN_IO = (byte)0x01;
        //串口1通道，高频读卡器
        public const byte CHAN_SER1_HFREADER = (byte)0x02;
        //串口2通道，指纹仪
        public const byte CHAN_SER2_FINGER = (byte)0x03;



        //成功状态
        public const byte SUCCESS_CODE = (byte)0x01;
        //锁已经开启
        public const byte LOCK_ALREADY_OPEN = (byte)0x02;
        //锁状态: 关闭
        public const byte LOCK_CLOSED = (byte)0x00;
        //锁状态: 开启
        public const byte LOCK_OPENED = (byte)0x01;
        //错误码表
        public const byte ERROR_SUCCESS = 0X10;

        public const byte CMD_IO_OUTPUT_1_OPEN = 0X70;
        public const byte CMD_IO_OUTPUT_1_CLOSE = 0X71;

        public const byte CMD_IO_OUTPUT_2_OPEN = 0X73;
        public const byte CMD_IO_OUTPUT_2_CLOSE = 0X74;

        public const byte CMD_IO_OUTPUT_1_READ = 0X72;
        public const byte CMD_IO_OUTPUT_2_READ = 0X75;

        public const byte CMD_IO_INPUT_1_OPEN = 0X80;
        public const byte CMD_IO_INPUT_1_CLOSE = 0X81;

        public const byte CMD_IO_INPUT_2_OPEN = 0X83;
        public const byte CMD_IO_INPUT_2_CLOSE = 0X84;

        public const byte CMD_IO_INPUT_1_READ = 0X82;
        public const byte CMD_IO_INPUT_2_READ = 0X85;




        public static byte[] PieceCommond(byte[] buf)
        {
            byte[] picecBuf = new byte[buf.Length + 4]; //前三 后1
            int len1 = (buf.Length + 1) / 256;
            int len2 = (buf.Length + 1) % 256;
            picecBuf[0] = Etv002DataProtocol.BEGIN_FLAG;
            picecBuf[1] = (byte)(len1 & 0xff);
            picecBuf[2] = (byte)(len2 & 0xff);
            Array.Copy(buf, 0, picecBuf, 3, buf.Length);
            picecBuf[picecBuf.Length - 1] = (byte)CheckSum(picecBuf, 0, picecBuf.Length - 1);
            return picecBuf;
        }

        public static int CheckSum(byte[] buf, int offset, int len)
        {
            int i = 0, uSum = 0;
            for (i = 0; i < len; i++)
            {
                int v = buf[i + offset];
                uSum += 0xff & v;
            }
            uSum = (~(uSum & 0xff)) + 1;
            return (uSum) & 0xff;
        }

        public static byte[] FingerCheckSum(byte[] buf, int offset, int len)
        {
            int uSum = 0;
            for (int i = 0; i < len; i++)
            {
                int v = buf[i + offset];
                uSum += 0xff & v;
            }
            byte[] ret = new byte[] { 0x00, 0x00 };
            ret[0] = (byte)((uSum / 256) & 0xff);
            ret[1] = (byte)((uSum % 256) & 0xff);
            return ret;
        }
    }
}
