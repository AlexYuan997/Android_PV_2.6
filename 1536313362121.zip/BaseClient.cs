﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Cabinet4Producer.Client
{
    public abstract class BaseClient
    {
        public string IP { get; set; }

        public string RemoteAddress { get; set; }

        protected TcpClient Client { get; set; }

        Thread thread;

        public bool KeepRecive { get; protected set; } = false;


        public BaseClient(TcpClient tcpClient)
        {
            this.Client = tcpClient;
            this.IP = ((System.Net.IPEndPoint)(Client.Client.RemoteEndPoint)).Address.ToString();
            this.RemoteAddress = ((System.Net.IPEndPoint)(Client.Client.RemoteEndPoint)).ToString();
            thread = new Thread(ReciveDatas);
            thread.Start();
        }

        public virtual void ReciveDatas()
        {
            KeepRecive = true;
        }


        protected void Send2Client(byte[] buf)
        {
            this.Client.GetStream().Write(buf, 0, buf.Length);
        }

        public virtual void Release()
        {
            KeepRecive = false;
            Client.Client.Close();
            this.OnDisconnected();
        }

        public event EventHandler Disconnected;

        protected virtual void OnDisconnected()
        {
            this.Disconnected?.Invoke(this, EventArgs.Empty);
        }

        public event EventHandler<LogArgs> Logged;
        protected void OnLogged(string log, bool error)
        {
            LogArgs e = new LogArgs(log, error);
            this.Logged?.Invoke(this, e);
        }
        protected void OnLogged(string log)
        {
            LogArgs e = new LogArgs(log);
            this.Logged?.Invoke(this, e);
        }
    }
}
