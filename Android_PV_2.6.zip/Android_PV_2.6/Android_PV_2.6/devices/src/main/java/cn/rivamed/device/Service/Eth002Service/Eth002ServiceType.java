package cn.rivamed.device.Service.Eth002Service;

public enum Eth002ServiceType {

    /**
     * 针对V26的Eth002模块的
     * */
    Eth002V26,
    Eth002V2

}
