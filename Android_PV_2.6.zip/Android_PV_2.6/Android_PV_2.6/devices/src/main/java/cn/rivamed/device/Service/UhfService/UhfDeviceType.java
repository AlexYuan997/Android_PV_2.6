package cn.rivamed.device.Service.UhfService;

public enum UhfDeviceType {
    UHF_READER_COLU,
    UHF_READER_COLU_NETTY,
    UHF_READER_RODINBELL
}
