/**
 * @Author 郝小鹏
 * @Description
 * @Date: Created in 2018-07-10 14:30
 * @Modyfied By :
 */
package cn.rivamed.callback;


/**
 *
 * 用于声明各种回调函数
 *
 *
 *
 * */