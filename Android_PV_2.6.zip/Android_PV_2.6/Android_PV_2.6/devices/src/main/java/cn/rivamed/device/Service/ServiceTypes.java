package cn.rivamed.device.Service;

public class ServiceTypes {
    public  static  final int  COLU_UHFREADER_SERVICE=1;
    public  static  final int  ETH003_UHFREADER_SERVICE=2;

}
