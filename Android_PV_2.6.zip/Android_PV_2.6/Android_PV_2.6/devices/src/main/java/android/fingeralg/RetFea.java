package android.fingeralg;

public class RetFea
{
  public byte[] retbytes; 
}